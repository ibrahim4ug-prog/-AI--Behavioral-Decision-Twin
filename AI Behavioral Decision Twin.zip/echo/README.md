# ECHO — AI Behavioral Decision Twin

Learns your decision patterns from history and predicts your likely choice in new situations.

**Architecture** (strict separation): LLM parser → Pydantic validation → embeddings + SQLite memory → pairwise
logistic-regression preference model → exact additive attribution → *LLM narrative only*.
The LLM never produces the prediction; it extracts features and explains a pre-computed result.

## Run
```
pip install -r requirements.txt
cp .env.example .env        # LLM_PROVIDER=none runs offline (heuristic extraction + hashing embeddings)
python -m scripts.seed_demo
streamlit run app/main.py
pytest
```
## Method notes
- Factor scores are per-option *favourability* (cost: cheap = high). Weights come from pairwise (chosen − rejected) logistic regression, no intercept.
- Confidence = softmax probability shrunk toward uniform by n/(n+5), so thin history gives humble confidence. Leave-one-out accuracy is on the Overview tab.
- Attribution is exact for a linear utility (equivalent to SHAP with a mean baseline). It is ML importance, not causal.
- Contradictions use neutral wording and make no psychological claims. Weights are estimated behavioural preferences, not psychological facts. Demo data is synthetic.
## Limits / next steps
Vector search is NumPy cosine (swap `Echo.similar` for FAISS/Chroma at scale); SQL is isolated in `database/store.py` for a Postgres migration; no calibration plot yet.
