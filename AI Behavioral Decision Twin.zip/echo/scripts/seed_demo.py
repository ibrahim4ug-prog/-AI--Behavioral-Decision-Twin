"""Seed a synthetic demo history. Run from project root: python -m scripts.seed_demo"""
from datetime import date, timedelta
from app.models.schemas import DecisionIn
from app.services.echo import Echo

def mk(q, opts, chosen, why, scores, dom): return dict(q=q, opts=opts, chosen=chosen, why=why, scores=scores, dom=dom)

DEMO = [
 mk("Which laptop should I buy?", ["Lenovo LOQ", "ASUS ROG", "MacBook Air"], "Lenovo LOQ", "Better GPU performance despite weight",
    {"Lenovo LOQ": {"performance": .9, "cost": .6, "portability": .3}, "ASUS ROG": {"performance": .95, "cost": .3, "portability": .2}, "MacBook Air": {"performance": .5, "cost": .4, "portability": .95}}, "technology"),
 mk("Which university offer?", ["Univ X", "Univ Y"], "Univ X", "Stronger AI research even though tuition is higher",
    {"Univ X": {"research": .9, "cost": .3, "career_opportunity": .8}, "Univ Y": {"research": .5, "cost": .8, "career_opportunity": .5}}, "education"),
 mk("Internship choice", ["Startup", "Big company"], "Startup", "More hands-on ML work, lower pay",
    {"Startup": {"research": .7, "cost": .4, "career_opportunity": .8}, "Big company": {"research": .4, "cost": .9, "career_opportunity": .6}}, "career"),
 mk("Phone upgrade", ["Phone A", "Phone B"], "Phone A", "Better performance, a bit pricier",
    {"Phone A": {"performance": .9, "cost": .4}, "Phone B": {"performance": .6, "cost": .8}}, "technology"),
 mk("Online course", ["Course 1", "Course 2"], "Course 1", "Strong career outcomes, costs more",
    {"Course 1": {"career_opportunity": .9, "cost": .3}, "Course 2": {"career_opportunity": .5, "cost": .9}}, "education"),
 mk("Apartment", ["Near campus", "Cheaper far"], "Near campus", "Short commute matters more than rent",
    {"Near campus": {"location": .9, "cost": .3}, "Cheaper far": {"location": .3, "cost": .8}}, "housing"),
 mk("Job offer", ["Job P", "Job Q"], "Job P", "Better growth, lower salary",
    {"Job P": {"career_opportunity": .9, "cost": .4, "research": .6}, "Job Q": {"career_opportunity": .5, "cost": .9, "research": .3}}, "career"),
 mk("Conference trip", ["Attend", "Skip"], "Attend", "Research networking is worth the expense",
    {"Attend": {"research": .8, "cost": .3, "convenience": .4}, "Skip": {"research": .3, "cost": .9, "convenience": .9}}, "career"),
]

def main():
    e = Echo(); start = date.today() - timedelta(days=30 * len(DEMO))
    for i, d in enumerate(DEMO):
        e.add_decision(DecisionIn(question=d["q"], options=d["opts"], chosen=d["chosen"], reasoning=d["why"],
                                  date=start + timedelta(days=30 * i), domain=d["dom"], option_scores=d["scores"]))
    print(f"Seeded {len(DEMO)} decisions.")

if __name__ == "__main__":
    main()
