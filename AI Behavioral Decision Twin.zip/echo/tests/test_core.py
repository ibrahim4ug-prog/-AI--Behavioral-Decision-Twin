from datetime import date
from app.database.store import DecisionStore
from app.embeddings.embedder import Embedder
from app.models.schemas import DecisionIn, ExtractedFeatures
from app.services.echo import Echo
from scripts.seed_demo import DEMO

def make():
    e = Echo(DecisionStore("sqlite:///:memory:"), Embedder())
    for i, d in enumerate(DEMO):
        e.add_decision(DecisionIn(question=d["q"], options=d["opts"], chosen=d["chosen"], reasoning=d["why"],
                                  date=date(2026, 1, i + 1), option_scores=d["scores"]))
    return e

def test_validation_clips():
    assert ExtractedFeatures.model_validate({"factors": {"Cost": 3, "x y": -1}}).factors == {"cost": 1.0, "x_y": 0.0}

def test_predict_prefers_research_option():
    p = make().predict("university choice", {"A": {"research": .9, "cost": .3}, "B": {"research": .4, "cost": .8}})
    assert p.predicted == "A" and p.ml_active

def test_what_if_lowers_probability():
    e = make(); sc = {"A": {"research": .9, "cost": .3}, "B": {"research": .4, "cost": .8}}
    b, m = e.what_if("u", sc, "A", "research", 0.1)
    assert m.probabilities["A"] < b.probabilities["A"]
