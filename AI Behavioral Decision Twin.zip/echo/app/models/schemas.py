"""Pydantic models. Factor scores are *favourability* in [0,1] (cost=0.9 means cheap)."""
from __future__ import annotations
from datetime import date
from typing import Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, model_validator

def _clip(d: Dict[str, float]) -> Dict[str, float]:
    return {str(k).strip().lower().replace(" ", "_"): min(1.0, max(0.0, float(v))) for k, v in d.items()}

class ExtractedFeatures(BaseModel):
    domain: str = "general"
    factors: Dict[str, float] = Field(default_factory=dict)          # importance to the user, 0-1
    option_scores: Dict[str, Dict[str, float]] = Field(default_factory=dict)  # option -> factor -> favourability
    reasoning_summary: str = ""
    decision_type: str = "tradeoff"

    @field_validator("factors")
    @classmethod
    def _f(cls, v): return _clip(v)

    @field_validator("option_scores")
    @classmethod
    def _o(cls, v): return {str(o): _clip(s) for o, s in v.items()}

    @field_validator("domain", "decision_type")
    @classmethod
    def _s(cls, v): return str(v).strip().lower() or "general"

class DecisionIn(BaseModel):
    question: str = Field(min_length=3)
    options: List[str] = Field(min_length=2)
    chosen: str
    reasoning: str = ""
    date: date = Field(default_factory=date.today)
    domain: Optional[str] = None
    confidence: float = Field(default=0.7, ge=0, le=1)
    option_scores: Dict[str, Dict[str, float]] = Field(default_factory=dict)  # optional manual input

    @model_validator(mode="after")
    def _chosen_in_options(self):
        if self.chosen not in self.options:
            raise ValueError("chosen must be one of options")
        return self

class Decision(BaseModel):
    id: int
    date: date
    domain: str
    question: str
    options: List[str]
    chosen: str
    reasoning: str
    factors: Dict[str, float]
    option_scores: Dict[str, Dict[str, float]]
    confidence: float
    metadata: Dict = Field(default_factory=dict)

class Prediction(BaseModel):
    predicted: str
    confidence: float
    probabilities: Dict[str, float]
    contributions: Dict[str, float]   # signed factor contributions, winner vs runner-up
    weights: Dict[str, float]
    similar: List[dict]
    ml_active: bool
    explanation: str
