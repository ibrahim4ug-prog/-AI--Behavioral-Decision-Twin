"""Sentence-transformers if installed, otherwise a deterministic hashing embedder (offline-safe)."""
from __future__ import annotations
import hashlib, logging, re
from typing import List
import numpy as np
from app.config import settings
log = logging.getLogger(__name__)
DIM = 384

class Embedder:
    def __init__(self):
        self.model = None
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(settings.embedding_model)
            log.info("Using sentence-transformers: %s", settings.embedding_model)
        except Exception as e:
            log.warning("Falling back to hashing embedder (%s)", type(e).__name__)

    def encode(self, texts: List[str]) -> np.ndarray:
        if self.model is not None:
            v = np.asarray(self.model.encode(texts, normalize_embeddings=True), dtype="float32")
        else:
            v = np.zeros((len(texts), DIM), dtype="float32")
            for i, t in enumerate(texts):
                toks = re.findall(r"[a-z0-9]+", t.lower())
                for tok in toks + [a + "_" + b for a, b in zip(toks, toks[1:])]:
                    v[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % DIM] += 1.0
            v = np.log1p(v)
        n = np.linalg.norm(v, axis=1, keepdims=True); n[n == 0] = 1
        return (v / n).astype("float32")

def decision_text(question: str, options, reasoning: str) -> str:
    return f"{question} Options: {', '.join(options)}. {reasoning}"
