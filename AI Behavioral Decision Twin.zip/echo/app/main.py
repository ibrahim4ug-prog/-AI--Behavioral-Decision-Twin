"""ECHO dashboard. Run: streamlit run app/main.py"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from datetime import date
import pandas as pd, streamlit as st
from app.ml.preferences import loo_accuracy
from app.models.schemas import DecisionIn
from app.services.echo import Echo

st.set_page_config(page_title="ECHO", page_icon="🔁", layout="wide")

@st.cache_resource
def get_echo() -> Echo: return Echo()
echo = get_echo()
ds = echo.store.all()

st.title("ECHO — AI Behavioral Decision Twin")
st.caption("Estimates behavioural preferences from past decisions. These are statistical estimates, not psychological facts.")
tabs = st.tabs(["Overview", "Preference Profile", "Memory", "Predict", "What-If", "Contradictions", "Evolution"])

def lines(txt: str): return [x.strip() for x in txt.splitlines() if x.strip()]

def scores_editor(key: str, options: list, factors: list) -> dict:
    ed = st.data_editor(pd.DataFrame(0.5, index=options, columns=factors), key=key, use_container_width=True)
    return {o: {f: float(ed.loc[o, f]) for f in factors} for o in options}

with tabs[0]:
    c = st.columns(4)
    c[0].metric("Decisions", len(ds)); c[1].metric("Domains", len({d.domain for d in ds}))
    c[2].metric("Avg. stated confidence", f"{sum(d.confidence for d in ds) / len(ds):.0%}" if ds else "–")
    if ds:
        _, imp, _ = echo.profile(); c[3].metric("Top factor", next(iter(imp), "–"))
        acc = loo_accuracy(ds)
        st.caption(f"Leave-one-out accuracy reproducing past choices: {acc:.0%}" if acc is not None else "Need 5+ scored decisions for validation.")
        st.dataframe(pd.DataFrame([{"date": d.date, "domain": d.domain, "question": d.question, "chosen": d.chosen} for d in ds[::-1][:8]]), use_container_width=True)
    with st.expander("➕ Add a historical decision", expanded=not ds):
        q = st.text_input("Question"); opts = lines(st.text_area("Options (one per line)"))
        chosen = st.selectbox("Chosen", opts) if len(opts) >= 2 else None
        why = st.text_area("Reasoning"); dt = st.date_input("Date", date.today())
        facs = [f.strip() for f in st.text_input("Factors to score (comma-separated; blank = LLM extraction)").split(",") if f.strip()]
        manual = scores_editor("add_scores", opts, facs) if facs and len(opts) >= 2 else {}
        st.caption("Scores = favourability 0–1 (cost: cheap = high).")
        if st.button("Save decision") and chosen:
            try:
                echo.add_decision(DecisionIn(question=q, options=opts, chosen=chosen, reasoning=why, date=dt, option_scores=manual))
                st.rerun()
            except Exception as e: st.error(str(e))

with tabs[1]:
    if ds:
        _, imp, active = echo.profile()
        st.bar_chart(pd.Series(imp, name="importance"))
        st.caption("Pairwise logistic-regression weights." if active else "Too little pairwise data; showing mean extracted importance.")
    else: st.info("Add decisions first (or run `python -m scripts.seed_demo`).")

with tabs[2]:
    s = st.text_input("Semantic search")
    if s: st.dataframe(pd.DataFrame(echo.similar(s, 5)), use_container_width=True)
    for d in ds[::-1]:
        with st.expander(f"{d.date} · {d.domain} · {d.question}"):
            st.write(f"**Chosen:** {d.chosen}  \n**Reasoning:** {d.reasoning}"); st.json(d.factors)
            if st.button("Delete", key=f"del{d.id}"): echo.store.delete(d.id); st.rerun()

with tabs[3]:
    q = st.text_input("Situation", value="University A costs $30k with excellent AI research; University B costs $20k with weaker research.")
    opts = lines(st.text_area("Options", "University A\nUniversity B"))
    known = list(echo.profile()[0]) if ds else []
    facs = st.multiselect("Factors", known, default=known[:4])
    if len(opts) >= 2 and facs:
        sc = scores_editor("pred_ed", opts, facs)
        if st.button("Predict"):
            try:
                p = echo.predict(q, sc); st.session_state["last"] = (q, sc)
                st.subheader(f"Predicted: {p.predicted}"); st.progress(p.confidence, text=f"Confidence {p.confidence:.0%}")
                st.bar_chart(pd.Series(p.probabilities))
                st.markdown("**ML factor contributions** (exact additive attribution; ML only)"); st.bar_chart(pd.Series(p.contributions))
                st.markdown("**Similar past decisions**"); st.dataframe(pd.DataFrame(p.similar), use_container_width=True)
                st.markdown("**LLM-generated explanation** (narrative, not causal proof)"); st.write(p.explanation)
            except Exception as e: st.error(str(e))

with tabs[4]:
    if "last" not in st.session_state: st.info("Run a prediction first.")
    else:
        q, sc = st.session_state["last"]; o = st.selectbox("Option", list(sc)); f = st.selectbox("Factor", list(sc[o]))
        v = st.slider("New favourability", 0.0, 1.0, float(sc[o][f]))
        b, m = echo.what_if(q, sc, o, f, v)
        st.dataframe(pd.DataFrame({"original": b.probabilities, "modified": m.probabilities}).assign(delta=lambda d: d.modified - d.original))
        st.write(f"**{b.predicted}** ({b.confidence:.0%}) → **{m.predicted}** ({m.confidence:.0%})")

with tabs[5]:
    sel = st.multiselect("Factors you say matter a lot", list(echo.profile()[1]) if ds else [])
    for c in echo.contradictions({f: 1.0 for f in sel}):
        st.warning(f"⚠ {c['factor']}: stated 1.00 vs estimated {c['estimated_from_history']:.2f}. {c['evidence']} {c['note']}")

with tabs[6]:
    dom = st.multiselect("Domains", sorted({d.domain for d in ds}))
    ev = echo.evolution(dom or None) if len(ds) >= 3 else pd.DataFrame()
    if ev.empty: st.info("Need 3+ scored decisions.")
    else:
        fs = st.multiselect("Factors", list(ev.columns), default=list(ev.columns)[:4])
        st.line_chart(ev[fs] if fs else ev)
