"""Orchestrates: parse -> embed -> store -> learn -> predict -> retrieve -> explain."""
from __future__ import annotations
import copy, logging
from typing import Dict, List, Optional
import numpy as np, pandas as pd
from app.database.store import DecisionStore
from app.embeddings.embedder import Embedder, decision_text
from app.explainability.attribution import contributions
from app.llm import provider
from app.ml import preferences as pref
from app.models.schemas import DecisionIn, Prediction

log = logging.getLogger(__name__)

class Echo:
    def __init__(self, store: Optional[DecisionStore] = None, embedder: Optional[Embedder] = None):
        self.store = store or DecisionStore()
        self.embedder = embedder or Embedder()

    def add_decision(self, d: DecisionIn) -> int:
        feats = provider.extract_features(d.question, d.options, d.chosen, d.reasoning)
        scores = d.option_scores or feats.option_scores
        rec = dict(date=d.date, domain=d.domain or feats.domain, question=d.question, options=d.options, chosen=d.chosen,
                   reasoning=d.reasoning, factors=feats.factors, option_scores=scores, confidence=d.confidence,
                   metadata={"decision_type": feats.decision_type, "summary": feats.reasoning_summary, "has_option_scores": bool(scores)})
        emb = self.embedder.encode([decision_text(d.question, d.options, d.reasoning)])[0]
        return self.store.add(rec, emb)

    def similar(self, text: str, k: int = 3) -> List[dict]:
        ids, mat = self.store.embeddings()
        if not ids: return []
        sims = mat @ self.embedder.encode([text])[0]
        by_id = {d.id: d for d in self.store.all()}
        return [{"id": ids[i], "question": by_id[ids[i]].question, "chosen": by_id[ids[i]].chosen,
                 "domain": by_id[ids[i]].domain, "similarity": float(sims[i])} for i in np.argsort(-sims)[:k]]

    def profile(self):
        w, active = pref.fit_weights(self.store.all())
        return w, pref.importance(w), active

    def predict(self, question: str, option_scores: Dict[str, Dict[str, float]], weights: Optional[Dict[str, float]] = None) -> Prediction:
        ds = self.store.all()
        w, active = (weights, True) if weights is not None else pref.fit_weights(ds)
        if not w: raise ValueError("No learned preferences yet: add decisions that include option scores.")
        probs = pref.score_options(option_scores, w, len(ds))
        ranked = sorted(probs, key=probs.get, reverse=True)
        contrib = contributions(option_scores, w, ranked[0], ranked[1])
        sim = self.similar(question + " " + " ".join(option_scores))
        text = (f"ML prediction: {ranked[0]} ({probs[ranked[0]]:.0%}). Top factor contributions vs {ranked[1]}: "
                f"{dict(list(contrib.items())[:3])}. Similar past decisions: {[(s['question'], s['chosen']) for s in sim]}.")
        fallback = (f"The model favours {ranked[0]} mainly because of {', '.join(list(contrib)[:2])}; similar past decisions "
                    "are listed above. This is an estimate from past behaviour, not a causal claim.")
        return Prediction(predicted=ranked[0], confidence=probs[ranked[0]], probabilities=probs, contributions=contrib,
                          weights=w, similar=sim, ml_active=active, explanation=provider.explain(text, fallback))

    def what_if(self, question: str, option_scores, option: str, factor: str, new_value: float):
        base = self.predict(question, option_scores)
        mod = copy.deepcopy(option_scores); mod.setdefault(option, {})[factor] = new_value
        return base, self.predict(question, mod, weights=base.weights)

    def contradictions(self, stated: Dict[str, float], tol: float = 0.4) -> List[dict]:
        ds = self.store.all(); _, imp, _ = self.profile(); out = []
        for f, s in stated.items():
            learned = imp.get(f)
            if learned is None or abs(s - learned) < tol: continue
            rel = [d for d in ds if d.chosen in d.option_scores and
                   max(o.get(f, .5) for o in d.option_scores.values()) - min(o.get(f, .5) for o in d.option_scores.values()) > .15]
            top = sum(d.option_scores[d.chosen].get(f, .5) >= max(o.get(f, .5) for o in d.option_scores.values()) - 1e-9 for d in rel)
            out.append({"factor": f, "stated": s, "estimated_from_history": learned,
                        "evidence": f"The option best on '{f}' was chosen in {top} of {len(rel)} decisions where options differed on it.",
                        "note": "Historical decisions appear inconsistent with the currently stated preference."})
        return out

    def evolution(self, domains: Optional[List[str]] = None) -> pd.DataFrame:
        ds = [d for d in self.store.all() if not domains or d.domain in domains]
        factors, rows = pref.all_factors(ds), {}
        for i in range(3, len(ds) + 1):
            w, _ = pref.fit_weights(ds[:i], factors)
            rows[str(ds[i - 1].date)] = pref.importance(w)
        return pd.DataFrame(rows).T.fillna(0.0) if rows else pd.DataFrame()
