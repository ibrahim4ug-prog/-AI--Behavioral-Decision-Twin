"""Pairwise preference learning (Bradley-Terry style): each (chosen - rejected) factor-score difference is a
positive example (its negation a negative one); a no-intercept logistic regression gives U(option) = w . scores."""
from __future__ import annotations
import logging
from typing import Dict, List, Optional, Tuple
import numpy as np
from sklearn.linear_model import LogisticRegression
from app.config import settings
from app.models.schemas import Decision

log = logging.getLogger(__name__)

def all_factors(decisions: List[Decision]) -> List[str]:
    return sorted({f for d in decisions for s in d.option_scores.values() for f in s})

def pairwise_data(decisions: List[Decision], factors: List[str]) -> Tuple[np.ndarray, np.ndarray]:
    X, y = [], []
    for d in decisions:
        if d.chosen not in d.option_scores: continue
        c = np.array([d.option_scores[d.chosen].get(f, 0.5) for f in factors])
        for o, s in d.option_scores.items():
            if o == d.chosen: continue
            diff = c - np.array([s.get(f, 0.5) for f in factors])
            X += [diff, -diff]; y += [1, 0]
    return np.array(X), np.array(y)

def prior_weights(decisions: List[Decision], factors: List[str]) -> Dict[str, float]:
    return {f: float(np.mean([d.factors[f] for d in decisions if f in d.factors] or [0.0])) for f in factors}

def fit_weights(decisions: List[Decision], factors: Optional[List[str]] = None) -> Tuple[Dict[str, float], bool]:
    """Returns (signed weights, ml_active). Falls back to mean stated importance when data is too thin."""
    factors = factors or all_factors(decisions)
    if not factors: return {}, False
    X, y = pairwise_data(decisions, factors)
    if len(set(y.tolist())) < 2 or len(decisions) < settings.min_decisions_for_ml:
        return prior_weights(decisions, factors), False
    clf = LogisticRegression(fit_intercept=False, C=1.0, max_iter=1000).fit(X, y)
    return dict(zip(factors, map(float, clf.coef_[0]))), True

def importance(weights: Dict[str, float]) -> Dict[str, float]:
    """Normalised |w| in [0,1]: an estimated behavioural preference, NOT a psychological fact."""
    m = max([abs(v) for v in weights.values()] or [1.0]) or 1.0
    return {k: abs(v) / m for k, v in sorted(weights.items(), key=lambda kv: -abs(kv[1]))}

def score_options(option_scores: Dict[str, Dict[str, float]], weights: Dict[str, float], n_decisions: int) -> Dict[str, float]:
    """Softmax over utilities, shrunk toward uniform when history is thin (simple calibration)."""
    opts = list(option_scores)
    u = np.array([sum(weights.get(f, 0) * option_scores[o].get(f, 0.5) for f in weights) for o in opts])
    p = np.exp(u - u.max()); p /= p.sum()
    lam = n_decisions / (n_decisions + settings.shrinkage_k)
    p = (1 - lam) / len(opts) + lam * p
    return dict(zip(opts, map(float, p)))

def loo_accuracy(decisions: List[Decision]) -> Optional[float]:
    """Leave-one-out accuracy at reproducing past choices (honest validation)."""
    ds = [d for d in decisions if d.chosen in d.option_scores]
    if len(ds) < 5: return None
    facs, hits = all_factors(ds), 0
    for i, d in enumerate(ds):
        w, _ = fit_weights(ds[:i] + ds[i + 1:], facs)
        p = score_options(d.option_scores, w, len(ds) - 1)
        hits += max(p, key=p.get) == d.chosen
    return hits / len(ds)
