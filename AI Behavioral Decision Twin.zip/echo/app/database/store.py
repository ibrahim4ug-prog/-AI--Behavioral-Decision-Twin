"""SQLite repository. All SQL is isolated here (plain SQL), so moving to PostgreSQL means
swapping the connection and placeholders only."""
from __future__ import annotations
import json, logging, sqlite3
from pathlib import Path
from typing import List
import numpy as np
from app.config import settings
from app.models.schemas import Decision

log = logging.getLogger(__name__)
SCHEMA = """CREATE TABLE IF NOT EXISTS decisions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, domain TEXT, question TEXT, options TEXT,
 chosen TEXT, reasoning TEXT, factors TEXT, option_scores TEXT, embedding BLOB,
 confidence REAL, metadata TEXT)"""
COLS = "id,date,domain,question,options,chosen,reasoning,factors,option_scores,confidence,metadata"

class DecisionStore:
    def __init__(self, url: str = settings.database_url):
        path = url.replace("sqlite:///", "")
        if path != ":memory:": Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.execute(SCHEMA); self.conn.commit()

    def add(self, d: dict, embedding: np.ndarray) -> int:
        cur = self.conn.execute(
            "INSERT INTO decisions(date,domain,question,options,chosen,reasoning,factors,option_scores,embedding,confidence,metadata) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (str(d["date"]), d["domain"], d["question"], json.dumps(d["options"]), d["chosen"], d["reasoning"],
             json.dumps(d["factors"]), json.dumps(d["option_scores"]), embedding.astype("float32").tobytes(),
             d["confidence"], json.dumps(d.get("metadata", {}))))
        self.conn.commit(); return int(cur.lastrowid)

    @staticmethod
    def _row(r) -> Decision:
        return Decision(id=r[0], date=r[1], domain=r[2], question=r[3], options=json.loads(r[4]), chosen=r[5],
                        reasoning=r[6], factors=json.loads(r[7]), option_scores=json.loads(r[8]),
                        confidence=r[9], metadata=json.loads(r[10] or "{}"))

    def all(self) -> List[Decision]:
        return [self._row(r) for r in self.conn.execute(f"SELECT {COLS} FROM decisions ORDER BY date,id")]

    def embeddings(self):
        rows = self.conn.execute("SELECT id, embedding FROM decisions ORDER BY id").fetchall()
        if not rows: return [], np.zeros((0, 1), dtype="float32")
        return [r[0] for r in rows], np.vstack([np.frombuffer(r[1], dtype="float32") for r in rows])

    def delete(self, did: int):
        self.conn.execute("DELETE FROM decisions WHERE id=?", (did,)); self.conn.commit()
