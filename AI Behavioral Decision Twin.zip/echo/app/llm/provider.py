"""Provider-agnostic LLM layer. LLM output is parsed + Pydantic-validated with a heuristic fallback.
The LLM never produces the prediction: it extracts features and narrates a pre-computed result."""
from __future__ import annotations
import json, logging, re
from typing import Optional
from pydantic import ValidationError
from app.config import settings
from app.models.schemas import ExtractedFeatures

log = logging.getLogger(__name__)
LEXICON = {
    "performance": ["performance", "gpu", "fast", "speed", "power"], "cost": ["cost", "price", "cheap", "tuition", "expensive", "afford", "budget"],
    "research": ["research", "lab", "publication"], "career_opportunity": ["career", "job", "placement", "internship", "growth"],
    "location": ["location", "city", "close", "distance", "commute"], "convenience": ["convenient", "easy", "simple", "comfort"],
    "portability": ["weight", "portable", "light"], "quality": ["quality", "reliable", "durable", "better"], "brand": ["brand", "reputation", "ranking"],
}
SYSTEM = "You extract structured decision features. Reply with ONLY a JSON object, no prose."

def complete(prompt: str, system: str = SYSTEM, max_tokens: int = 900) -> Optional[str]:
    p = settings.llm_provider
    try:
        if p == "anthropic":
            import anthropic
            r = anthropic.Anthropic().messages.create(model=settings.llm_model or "claude-sonnet-4-6", max_tokens=max_tokens,
                                                      system=system, messages=[{"role": "user", "content": prompt}])
            return "".join(b.text for b in r.content if getattr(b, "text", None))
        if p == "openai":
            from openai import OpenAI
            r = OpenAI().chat.completions.create(model=settings.llm_model or "gpt-4o-mini", max_tokens=max_tokens,
                                                 messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}])
            return r.choices[0].message.content
    except Exception as e:
        log.error("LLM call failed: %s", e)
    return None

def _parse_json(text: str) -> Optional[dict]:
    m = re.search(r"\{.*\}", text or "", re.S)
    try: return json.loads(m.group(0)) if m else None
    except json.JSONDecodeError: return None

def heuristic_extract(question: str, options, reasoning: str) -> ExtractedFeatures:
    text = (question + " " + reasoning).lower()
    f = {k: min(1.0, 0.5 + 0.2 * sum(text.count(w) for w in ws)) for k, ws in LEXICON.items() if any(w in text for w in ws)}
    return ExtractedFeatures(domain="general", factors=f, reasoning_summary=reasoning[:200])

def extract_features(question: str, options: list, chosen: str, reasoning: str) -> ExtractedFeatures:
    prompt = (f"Decision: {question}\nOptions: {options}\nChosen: {chosen}\nReason: {reasoning}\n\n"
              'Return JSON: {"domain": str, "factors": {factor: importance 0-1}, "option_scores": {option: {factor: favourability 0-1 '
              '(1 = best on that factor; for cost, cheap = high)}}, "reasoning_summary": str, "decision_type": str}. '
              "Use snake_case factor names. Score every option on every factor.")
    raw = complete(prompt)
    if raw:
        data = _parse_json(raw)
        if data:
            try:
                return ExtractedFeatures.model_validate(data)
            except ValidationError as e:
                log.warning("LLM output failed validation: %s", e.errors()[:2])
    return heuristic_extract(question, options, reasoning)

def explain(prompt: str, fallback: str) -> str:
    return complete(prompt, system="You explain a pre-computed prediction in 3-5 sentences. Do not change the predicted option or "
                    "confidence. Use neutral language, make no psychological claims, and note you are not proving causality.") or fallback
