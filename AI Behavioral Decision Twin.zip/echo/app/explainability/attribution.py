"""Exact additive attribution: for a linear utility, w_f * (x_f[A] - x_f[B]) equals the SHAP value of the
A-vs-B utility gap (mean-reference baseline). This is ML feature importance, separate from LLM prose."""
from __future__ import annotations
from typing import Dict

def contributions(option_scores: Dict[str, Dict[str, float]], weights: Dict[str, float], winner: str, other: str) -> Dict[str, float]:
    c = {f: w * (option_scores[winner].get(f, 0.5) - option_scores[other].get(f, 0.5)) for f, w in weights.items()}
    return dict(sorted(c.items(), key=lambda kv: -abs(kv[1])))
