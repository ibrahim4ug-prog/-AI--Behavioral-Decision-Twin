"""Central configuration, read from environment / .env (never hard-code keys)."""
from __future__ import annotations
import logging, os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

@dataclass(frozen=True)
class Settings:
    llm_provider: str = os.getenv("LLM_PROVIDER", "none").lower()
    llm_model: str = os.getenv("LLM_MODEL", "")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///data/echo.db")
    min_decisions_for_ml: int = 3
    shrinkage_k: float = 5.0   # confidence shrinks toward uniform when data is scarce

settings = Settings()
